package com.example.cs360projectthreeoptiontwoeventtracker;


public class MainActivity extends LoginActivity {
}