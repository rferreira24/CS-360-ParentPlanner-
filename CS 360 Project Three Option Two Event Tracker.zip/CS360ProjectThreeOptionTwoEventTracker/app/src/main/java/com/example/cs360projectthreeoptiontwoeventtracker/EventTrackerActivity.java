package com.example.cs360projectthreeoptiontwoeventtracker;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.database.Cursor;
import android.widget.Toast;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.TextView;
import android.content.Intent;

public class EventTrackerActivity extends AppCompatActivity {
    //UI components from event tracker xml file
    EditText editEventName, editEventDate, editEventTime, editEventInfo;
    Button btnAddEvent;
    GridLayout gridEvents;
    //connects to my databasehelper class
    DatabaseHelper databaseHelper;
    //stores ID of event that is being updated
    int selectedEventId = -1;
    //Added button that takes user to SMS notication settings
    Button btnSmsSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_tracker);

        editEventName = findViewById(R.id.editEventName);
        editEventDate = findViewById(R.id.editEventDate);
        editEventTime = findViewById(R.id.editEventTime);
        editEventInfo = findViewById(R.id.editEventInfo);
        btnAddEvent = findViewById(R.id.btnAddEvent);
        gridEvents = findViewById(R.id.gridEvents);
        databaseHelper = new DatabaseHelper(this);
        btnSmsSettings = findViewById(R.id.btnSmsSettings);
        btnSmsSettings.setOnClickListener(V -> {
            Intent intent = new Intent(EventTrackerActivity.this, SmsActivity.class);
            startActivity(intent);
        });

        //allows user to add events
        btnAddEvent.setOnClickListener(v -> {
            String name = editEventName.getText().toString();
            String date = editEventDate.getText().toString();
            String time = editEventTime.getText().toString();
            String info = editEventInfo.getText().toString();

            //checks if name, date and time is empty
            //if empty, displays message
            if (name.isEmpty() || date.isEmpty() || time.isEmpty()) {
                Toast.makeText(this, "Please enter event name, date and time",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            //Checks if user is updating event
            if (selectedEventId == -1) {
                boolean added = databaseHelper.addEvent(name, date, time, info);

                //Displays message if event is added successfully
                if (added) {
                    Toast.makeText(this, "Event successfully added",
                            Toast.LENGTH_SHORT).show();
                //if unable to add event, it displays error message
                } else {
                    Toast.makeText(this, "Unable to add event",
                            Toast.LENGTH_SHORT).show();
                }
            } else {
                boolean updated = databaseHelper.updateEvent(selectedEventId, name, date, time, info);

                if (updated) {
                    Toast.makeText(this, "Event successfully updated",
                            Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Unable to update event",
                            Toast.LENGTH_SHORT).show();
                }

                selectedEventId = -1;
                btnAddEvent.setText("Add Event");
            }

            clearFields();
            loadEvents();
        });

        loadEvents();
    }

    //Loads events from database to event screen
    private void loadEvents() {
        gridEvents.removeAllViews();

        addTextToGrid("Event");
        addTextToGrid("Date");
        addTextToGrid("Time");
        addTextToGrid("Remove");

        Cursor cursor = databaseHelper.getEvents();

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String date = cursor.getString(2);
            String time = cursor.getString(3);
            String info = cursor.getString(4);

            TextView nameView = new TextView(this);
            nameView.setText(name);
            nameView.setPadding(6, 6, 6, 6);

            nameView.setOnClickListener(v -> {
                selectedEventId = id;
                editEventName.setText(name);
                editEventDate.setText(date);
                editEventTime.setText(time);
                editEventInfo.setText(info);
                btnAddEvent.setText("Update Event");
            });

            gridEvents.addView(nameView);
            addTextToGrid(date);
            addTextToGrid(time);

            Button deleteButton = new Button(this);
            deleteButton.setText("X");
            deleteButton.setOnClickListener(v -> {
                databaseHelper.deleteEvent(id);
                selectedEventId = -1;
                btnAddEvent.setText("Add Event");
                clearFields();
                loadEvents();
            });

            gridEvents.addView(deleteButton);
        }

        cursor.close();
    }

    private void addTextToGrid(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(6, 6, 6, 6);
        gridEvents.addView(textView);
    }

    private void clearFields() {
        editEventName.setText("");
        editEventDate.setText("");
        editEventTime.setText("");
        editEventInfo.setText("");
    }
}
