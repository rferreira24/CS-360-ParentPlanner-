package com.example.cs360projectthreeoptiontwoeventtracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    //UI components for SMS permissions
    Button btnAllowSms, btnDenySms;
    TextView txtPermissionStatus;

    //Request code for SMS permission
    private static final int SMS_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        //Connects XML elements to my Java variables
        btnAllowSms = findViewById(R.id.btnAllowSms);
        btnDenySms = findViewById(R.id.btnDenySms);
        txtPermissionStatus = findViewById(R.id.txtPermissionStatus);

        //Requests SMS permission from the user
        btnAllowSms.setOnClickListener(v -> {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        });

        //Allows the user to decline SMS notifications
        btnDenySms.setOnClickListener(v -> {
            txtPermissionStatus.setText("Permission Status: Denied");

            Toast.makeText(
                    this,
                    "SMS notifications disabled",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // Displays current permission status
        checkPermissionStatus();
    }

    // Checks whether SMS permission has been granted
    private void checkPermissionStatus() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            txtPermissionStatus.setText("Permission Status: Granted");

        } else {

            txtPermissionStatus.setText("Permission Status: Not Granted");
        }
    }

    //Handles user response to the permission request
    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {

            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                txtPermissionStatus.setText("Permission Status: Granted");

                Toast.makeText(
                        this,
                        "SMS notifications enabled",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                txtPermissionStatus.setText("Permission Status: Denied");

                Toast.makeText(
                        this,
                        "SMS permission denied. App will still function normally.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        }
    }
}
