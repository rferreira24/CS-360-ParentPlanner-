package com.example.cs360projectthreeoptiontwoeventtracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;


public class LoginActivity extends AppCompatActivity {
    //connencts Login xml to java
    EditText editUsername, editPassword;
    Button btnLogin, btnCreateAccount;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);
        databaseHelper = new DatabaseHelper(this);

        //creates ParentPlanner account
        btnCreateAccount.setOnClickListener( v -> {
            String username = editUsername.getText().toString();
            String password = editPassword.getText().toString();

            //loops that check if information is added
            // checks if account is already created

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,"Plase Enter Login Information",
                        Toast.LENGTH_SHORT).show();
            } else {
                boolean added = databaseHelper.addUser(username,password);
                if (added) {
                    Toast.makeText(this, "Account Created",
                            Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Account Already Created ",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Validates users login
        btnLogin.setOnClickListener(v -> {
            String username = editUsername.getText().toString();
            String password = editPassword.getText().toString();
            boolean validLogin = databaseHelper.checkUser(username, password);

            //loop that checks if login information is correct
            //If login is correct, it sends user to EventTracker UI
            if (validLogin) {
                Toast.makeText(this, "Login Successfull",
                        Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(LoginActivity.this,
                        EventTrackerActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Wrong username or password",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
