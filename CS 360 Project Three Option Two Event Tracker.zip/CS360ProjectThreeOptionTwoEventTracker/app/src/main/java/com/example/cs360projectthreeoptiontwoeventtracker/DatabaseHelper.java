package com.example.cs360projectthreeoptiontwoeventtracker;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "EventTracker.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // User Login data table
        db.execSQL(
                "CREATE TABLE users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "username TEXT UNIQUE," +
                        "password TEXT)"
        );

        // Event data table
        db.execSQL(
                "CREATE TABLE events(" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "event_name TEXT," +
                        "event_date TEXT," +
                        "event_time TEXT," +
                        "event_details TEXT)"
        );
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS events");
        onCreate(db);
    }

    //Adds new user in the ParentPlanner Database
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this. getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put ("username", username);
        values.put("password", password);
        long result = db.insert("users", null, values);
        return result != -1;
    }

    // Checks login information
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM users WHERE username=? AND password=?",
                new String[]{username, password}
        );
        boolean exists = cursor.getCount() > 0;
         cursor.close();
         return exists;
    }

    //Adds events to the event table
    public boolean addEvent(String name,
                            String date,
                            String time,
                            String details) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("event_name", name);
        values.put("event_date", date);
        values.put("event_time", time);
        values.put("event_details", details);
        long result =db.insert("events", null,values);
        return result != -1;
    }

    //Gets events from that events database
    public Cursor getEvents() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM events", null);
    }

    //Deletes the events by ID
    public boolean deleteEvent(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(
                "events",
                "id=?",
                new String[]{String.valueOf(id)}
        );
        return result > 0;
    }

    // Updates existing event
    public boolean updateEvent(int id,
                               String name,
                               String date,
                               String time,
                               String details) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("event_name", name);
        values.put("event_date", date);
        values.put("event_time", time);
        values.put("event_details",details);

        int result = db.update(
                "events",
                values,
                "id=?",
                new String[]{String.valueOf(id)}
        );
        return result > 0;
    }
}
